package com.example.baithuchanh2

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.baithuchanh2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Kích hoạt View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Thiết lập sự kiện cho nút "Tạo"
        binding.buttonTao.setOnClickListener {
            xuLyTaoDanhSach()
        }
    }

    private fun xuLyTaoDanhSach() {
        // 1. Lấy dữ liệu nhập vào
        val soLuongString = binding.editTextSoLuong.text.toString().trim()

        // 2. Xóa thông báo lỗi và danh sách cũ
        binding.textViewThongBaoLoi.visibility = ViewGroup.GONE
        binding.layoutDanhSach.removeAllViews()

        // 3. Kiểm tra tính hợp lệ và chuyển đổi sang Int
        val soLuong: Int? = soLuongString.toIntOrNull()

        if (soLuong != null && soLuong > 0) {
            // Dữ liệu hợp lệ (số nguyên dương)
            taoVaHienThiDanhSach(soLuong)
        } else {
            // Dữ liệu không hợp lệ (nhập chữ, rỗng, hoặc số 0/số âm)
            hienThiThongBaoLoi()
        }
    }

    private fun hienThiThongBaoLoi() {
        binding.textViewThongBaoLoi.visibility = ViewGroup.VISIBLE
        // Đặt màu đỏ và text
        binding.textViewThongBaoLoi.setTextColor(Color.RED)
        binding.textViewThongBaoLoi.text = "Dữ liệu bạn nhập không hợp lệ"
    }

    private fun taoVaHienThiDanhSach(n: Int) {
        // Lặp từ 1 đến N và tạo các Button động
        for (i in 1..n) {
            val button = Button(this).apply {
                text = i.toString() // Nhãn của nút là số thứ tự
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, // Chiều rộng full
                    ViewGroup.LayoutParams.WRAP_CONTENT  // Chiều cao tự động
                ).apply {
                    setMargins(0, 0, 0, 8) // Đặt margin dưới 8dp
                }
                // Thiết lập kiểu dáng cơ bản giống các hình ảnh bạn cung cấp
                setBackgroundColor(Color.RED)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            }
            binding.layoutDanhSach.addView(button)
        }
    }
}